﻿using System;
using System.IO;

namespace DiceGame
{
    public class InsertCodeHere
    {
        public void MyCode()
        {
            // The FIRST line of code should be BELOW this line
            
            // The LAST line of code should be ABOVE this line
        }
    }
}