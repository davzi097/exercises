﻿using CryptoCrownLib;

namespace CryptoCrowns
{
    public class MinerWithTasks : MinerBase
    {
        public MinerWithTasks(string owner) : base(owner)
        {
        }

        public override void MineSingleCryptoCrown()
        {
            // Add your own super-efficient 
            // Task-based code here!
        }
    }
}