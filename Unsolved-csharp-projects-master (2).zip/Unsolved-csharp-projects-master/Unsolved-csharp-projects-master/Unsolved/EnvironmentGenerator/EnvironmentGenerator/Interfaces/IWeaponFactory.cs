﻿namespace EnvironmentGenerator.Interfaces
{
    public interface IWeaponFactory
    {
        IWeapon Create();
    }
}