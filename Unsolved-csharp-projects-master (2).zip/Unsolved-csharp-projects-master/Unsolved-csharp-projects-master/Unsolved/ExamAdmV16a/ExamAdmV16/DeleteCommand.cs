﻿namespace ExamAdmV16
{
    public class DeleteCommand : CommandBase
    {
        public override bool CanExecute(object parameter)
        {
            // TODO - implement CanExecute correctly
            return false;
        }

        public override void Execute(object parameter)
        {
            // TODO - implement Execute correctly
        }
    }
}