﻿using System;

namespace DBandEFHotel
{
    class Program
    {
        static void Main(string[] args)
        {

            // Write some test code here...

            Console.WriteLine("Done, press any key to close application...");
            Console.ReadKey();
        }
    }
}
