﻿namespace BankV05
{
    /// <summary>
    /// This class represents a very simple bank account.
    /// Only the amount of money on the account is represented.
    /// </summary>
    public class BankAccount
    {
        private double _balance;
        private string _nameOfAccountHolder;

        public BankAccount()
        {
            _balance = 0.0;
            _nameOfAccountHolder = "David";
        }

        public string NameOfAccountHolder
        {
            get { return _nameOfAccountHolder; }
        }

        public double Balance
        {
            get { return _balance;}
        }

        public void Deposit(double amount)
        {
            _balance = _balance + amount;
        }

        public void Withdraw(double amount)
        {
            _balance = _balance - amount;
        }
    }
}