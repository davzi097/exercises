﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeesV10
{
    public class Employee
    {
        private string _name;
        private int _hoursPerWeek;

        public Employee(string name, int hoursPerWeek)
        {
            Name = name;
            HoursPerWeek = hoursPerWeek;
        }

        public string Name { get => _name; set => _name = value; }
        public int HoursPerWeek { get => _hoursPerWeek; set => _hoursPerWeek = value; }
    }
}
