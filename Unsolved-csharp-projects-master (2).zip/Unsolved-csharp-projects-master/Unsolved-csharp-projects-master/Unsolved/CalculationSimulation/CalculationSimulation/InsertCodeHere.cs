﻿using System;

namespace CalculationSimulation
{
    public class InsertCodeHere
    {
        public void MyCode()
        {
            // The FIRST line of code should be BELOW this line

            Manager.Run();

            // The LAST line of code should be ABOVE this line
        }
    }
}