﻿namespace ClockV10
{
    public class Clock
    {
        int _hour;
        int _minute;

        public Clock(int hour, int minute)
        {
            _hour = hour;
            _minute = minute;
        }
        public int Hour
        {
            get { return _hour; }
            set { _hour = value; }
        }
        public int Minute
        {
            get { return _minute; }
            set { _minute = value; }
        }
        public static void Time(int minute)
        {
            minute = minute + 1;
        }


    }
}