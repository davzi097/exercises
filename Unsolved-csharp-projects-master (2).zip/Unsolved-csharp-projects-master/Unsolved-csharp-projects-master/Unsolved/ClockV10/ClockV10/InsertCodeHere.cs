﻿using System;
using System.Security.Cryptography.X509Certificates;

namespace ClockV10
{
    public class InsertCodeHere
    {
        public void MyCode()
        {
            // The FIRST line of code should be BELOW this line
            Clock c1 = new Clock(12, 44);
            Console.WriteLine($"The time is {c1.Hour}:{c1.Minute}");

            for (int x = 0;  x < 60; x++)
            {
                Clock.Time(c1.Minute);
                {
                    c1.Minute++;
                }

                if (c1.Minute >= 60)
                {
                    c1.Hour++;
                    c1.Minute = 0;
                }

                Console.WriteLine($"The time is {c1.Hour}:{c1.Minute}");
            }
            // The LAST line of code should be ABOVE this line
        }
    }
}