# Unsolved-csharp-projects
This repository contains the **unsolved** versions of the C# projects used for the exercises found in the **"C# Programming Exercises"** 
document (see the Teaching-materials repository).

The corresponding solved versions of the C# projects are found in the repository Solved-csharp-projects.
