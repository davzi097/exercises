﻿namespace EnvironmentGenerator.Interfaces
{
    public interface IBuilding : IEnvironmentElement
    {
        int Height { get; }
    }
}