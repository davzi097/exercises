﻿namespace EnvironmentGenerator.Interfaces
{
    public interface IWeapon : IEnvironmentElement
    {
        int Damage { get; }
    }
}