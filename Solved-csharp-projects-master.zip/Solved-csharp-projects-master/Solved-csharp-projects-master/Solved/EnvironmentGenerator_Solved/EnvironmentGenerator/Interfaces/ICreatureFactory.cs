﻿namespace EnvironmentGenerator.Interfaces
{
    public interface ICreatureFactory
    {
        ICreature Create();
    }
}