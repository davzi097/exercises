﻿namespace EnvironmentGenerator.Interfaces
{
    public enum EnvironmentTypes
    {
        Future,
        Medieval
    }
}