﻿namespace EnvironmentGenerator.Interfaces
{
    public interface ICreature : IEnvironmentElement
    {
        string Description { get; }
    }
}