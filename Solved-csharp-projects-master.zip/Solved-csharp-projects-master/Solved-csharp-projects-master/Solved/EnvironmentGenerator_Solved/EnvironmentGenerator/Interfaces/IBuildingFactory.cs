﻿namespace EnvironmentGenerator.Interfaces
{
    public interface IBuildingFactory
    {
        IBuilding Create();
    }
}