﻿using System;
// ReSharper disable UnusedParameter.Local

namespace Fight1v1
{
    class Program
    {
        static void Main(string[] args)
        {
            Fight1v1ManagerTest.Run();

            Console.WriteLine("Press any key to close application");
            Console.ReadKey();
        }
    }
}
