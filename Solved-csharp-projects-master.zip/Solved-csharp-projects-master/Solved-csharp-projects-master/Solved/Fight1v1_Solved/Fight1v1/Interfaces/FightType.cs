﻿namespace Fight1v1
{
    /// <summary>
    /// Different kinds of fight types.
    /// </summary>
    public enum FightType
    {
        Fair,
        BiasedA
    }
}