﻿namespace Fight1v1
{
    /// <summary>
    /// Interface for a 1v1 fight manager.
    /// </summary>
    public interface IFight1v1Manager
    {
        void Fight();
    }
}